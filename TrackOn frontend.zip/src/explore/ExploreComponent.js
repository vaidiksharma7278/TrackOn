import React from "react";
// import CourseContent from "components/common/CourseContent";

import {
  SiHtml5,
  SiJavascript,
  SiReact,
  SiAngular,
  SiDjango,
  SiFlutter,
} from "react-icons/si";
import { FaVuejs, FaNodeJs, FaPython } from "react-icons/fa";

const COURSES = [
  {
    id: 0,
    name: "HTML/CSS",
    logo: <SiHtml5 className="z-30 text-6xl text-blue-400 sm:text-9xl" />,
  },
  {
    id: 1,
    name: "Javascript",
    logo: <SiJavascript className="z-30 text-6xl text-blue-400 sm:text-9xl" />,
  },
  {
    id: 2,
    name: "React",
    logo: <SiReact className="z-30 text-6xl text-blue-400 sm:text-9xl" />,
  },
  {
    id: 3,
    name: "Vue.js",
    logo: <FaVuejs className="z-30 text-6xl text-blue-400 sm:text-9xl" />,
  },
  {
    id: 4,
    name: "Angular",
    logo: <SiAngular className="z-30 text-6xl text-blue-400 sm:text-9xl" />,
  },
  {
    id: 5,
    name: "Node.js",
    logo: <FaNodeJs className="z-30 text-6xl text-blue-400 sm:text-9xl" />,
  },
  {
    id: 6,
    name: "Python",
    logo: <FaPython className="z-30 text-6xl text-blue-400 sm:text-9xl" />,
  },
  {
    id: 7,
    name: "Django",
    logo: <SiDjango className="z-30 text-6xl text-blue-400 sm:text-9xl" />,
  },
  {
    id: 8,
    name: "Flutter",
    logo: <SiFlutter className="z-30 text-6xl text-blue-400 sm:text-9xl" />,
  },
];

const ExploreComponent = ({ response, selected }) => {
  return (
    <section className="col-span-12 mt-4 lg:col-span-9">
      <div className="w-full space-y-4 rounded-xl">
        <div className="relative flex items-center justify-end gap-4 p-8 overflow-hidden bg-blue-50 rounded-3xl">
          <h1 className="absolute text-4xl font-black text-blue-200 uppercase sm:text-7xl lg:text-8xl left-8">
            {COURSES[selected].name}
          </h1>
          {COURSES[selected].logo}
        </div>

        <hr />

        {/* <CourseContent courses={response} /> */}
      </div>
    </section>
  );
};

export default ExploreComponent;
